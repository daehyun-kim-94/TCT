package com.lgcns.test;

public class RunManager {

	public static void main(String[] args) {
		new Main().run();
	}
}
